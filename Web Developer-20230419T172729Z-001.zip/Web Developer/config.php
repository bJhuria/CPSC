<?php
    define('DB_HOST', "cpsc-recall-instance.c4ll0i5tmary.us-east-2.rds.amazonaws.com");
    define('DB_USER', "webdev");
    define('DB_PASS', "cuvuV1ju1A");
    define('DB_NAME', "CPSC_RecallDB");
    define('DB_PORT', "3306");
?>